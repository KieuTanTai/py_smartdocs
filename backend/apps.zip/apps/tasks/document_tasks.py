"""
Document tasks module.
Celery tasks for document processing.
"""

from pathlib import Path
from celery import shared_task
from backend.apps.config.container import BackendContainer
from backend.apps.core.enums.e_provider_name import EProviderName
from backend.apps.services.chat.models import DocumentModel


class DocumentTasks:
    def __init__(self):
        self.container = BackendContainer()

    def _build_upload_job(self):
        return self.container.upload_job()

    def _resolve_provider(self, provider_name: str) -> EProviderName:
        try:
            return EProviderName(provider_name)
        except ValueError as exc:
            raise ValueError(f"Unsupported provider: {provider_name}") from exc

    def _get_document(self, document_id: str) -> DocumentModel:
        return DocumentModel.objects.get(pk=document_id)

    def _run_upload_job(self, document_id: str, provider: EProviderName) -> dict:
        document = self._get_document(document_id)
        if not document.file_path:
            raise ValueError(f"Document {document_id} does not have a saved file path")
        upload_job = self._build_upload_job()
        return upload_job.run(document_id=document_id, file_path=Path(document.file_path), provider=provider)

    @shared_task(name="backend.apps.tasks.document_tasks.upload_document_task")
    def upload_document(self, document_id: str, provider_name: str = EProviderName.MISTRAL.value):
        provider = self._resolve_provider(provider_name)

        document = self._get_document(document_id)
        document.status = "processing"
        document.save(update_fields=["status"])

        try:
            result = self._run_upload_job(document_id, provider)
            document.status = "indexed"
            document.save(update_fields=["status"])
            return result
        except Exception as exc:
            document.status = "failed"
            document.save(update_fields=["status"])
            raise exc

    @shared_task(name="backend.apps.tasks.document_tasks.process_document")
    def process_document(self, document_id: str, provider_name: str = EProviderName.MISTRAL.value):
        return self.upload_document(document_id, provider_name)

    @shared_task(name="backend.apps.tasks.document_tasks.normalize_document")
    def normalize_document(self, document_id: str, raw_text: str):
        normalizer = self.container.normalize()
        return normalizer.normalize(raw_text)

    @shared_task(name="backend.apps.tasks.document_tasks.chunk_document")
    def chunk_document(self, document_id: str, normalized_text: str):
        chunker = self.container.chunker()
        return chunker.create_chunks(normalized_text)

    @shared_task(name="backend.apps.tasks.document_tasks.index_document")
    def index_document(self, document_id: str, chunk_texts, provider_name: str = EProviderName.MISTRAL.value):
        provider = self._resolve_provider(provider_name)
        document = self._get_document(document_id)
        if not document.file_path:
            raise ValueError(f"Document {document_id} does not have a saved file path")

        upload_job = self._build_upload_job()
        return upload_job.run(document_id=document_id, file_path=Path(document.file_path), provider=provider)

    @shared_task(name="backend.apps.tasks.document_tasks.summarize_document")
    def summarize_document(self, document_id: str):
        document = self._get_document(document_id)
        return {
            "document_id": document_id,
            "status": document.status,
            "summary": None,
        }