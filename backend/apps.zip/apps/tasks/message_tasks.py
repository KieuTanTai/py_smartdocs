"""
Message tasks module.
Celery tasks for chat message processing.
"""

from celery import shared_task
from backend.apps.config.container import BackendContainer
from backend.apps.core.enums.e_provider_name import EProviderName


class MessageTasks:
    def __init__(self):
        self.container = BackendContainer()

    def _build_message_job(self):
        return self.container.message_job()

    def _resolve_provider(self, provider_name: str) -> EProviderName:
        try:
            return EProviderName(provider_name)
        except ValueError as exc:
            raise ValueError(f"Unsupported provider: {provider_name}") from exc

    @shared_task(name="backend.apps.tasks.message_tasks.process_message")
    def process_message(
        self,
        conversation_id: str,
        content: str,
        provider_name: str,
        model_name: str | None = None,
    ):
        provider = self._resolve_provider(provider_name)
        message_job = self._build_message_job()
        return message_job.run(
            conversation_id=conversation_id,
            content=content,
            provider=provider,
            model_name=model_name,
        )